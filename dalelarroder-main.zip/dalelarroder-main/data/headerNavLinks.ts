const headerNavLinks = [
  { href: '/blog', title: 'Blog' },
  // { href: '/projects', title: 'Projects' },
  { href: '/about', title: 'About' },
  { href: '/uses', title: 'Uses' },
]

export default headerNavLinks
