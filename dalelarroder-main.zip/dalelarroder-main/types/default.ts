export enum EnvironmentType {
  Dev = 'development',
  Prod = 'production',
  Test = 'test',
}
